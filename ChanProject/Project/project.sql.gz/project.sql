-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2019 at 09:14 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `evaluation`
--

CREATE TABLE `evaluation` (
  `eval_id` int(12) NOT NULL,
  `evaInstructorOne` int(5) NOT NULL,
  `evaInstructorTwo` int(5) NOT NULL,
  `evaInstructorThree` int(5) NOT NULL,
  `evaInstructorFour` int(5) NOT NULL,
  `evaInstructorFive` int(11) NOT NULL,
  `evaInstructorSix` int(11) NOT NULL,
  `evaTrainingOne` int(5) NOT NULL,
  `evaTrainingTwo` int(5) NOT NULL,
  `evaTrainingThree` int(5) NOT NULL,
  `evaTrainingFour` int(5) NOT NULL,
  `evaTrainingFive` int(5) NOT NULL,
  `evaTrainingSix` int(5) NOT NULL,
  `evaCenterOne` int(11) NOT NULL,
  `evaCenterTwo` int(11) NOT NULL,
  `evaCenterThree` int(11) NOT NULL,
  `evaCenterFour` int(11) NOT NULL,
  `evaCenterFive` int(11) NOT NULL,
  `evaCenterSix` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `evaluation`
--

INSERT INTO `evaluation` (`eval_id`, `evaInstructorOne`, `evaInstructorTwo`, `evaInstructorThree`, `evaInstructorFour`, `evaInstructorFive`, `evaInstructorSix`, `evaTrainingOne`, `evaTrainingTwo`, `evaTrainingThree`, `evaTrainingFour`, `evaTrainingFive`, `evaTrainingSix`, `evaCenterOne`, `evaCenterTwo`, `evaCenterThree`, `evaCenterFour`, `evaCenterFive`, `evaCenterSix`) VALUES
(131, 5, 4, 5, 4, 5, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `users_id` int(255) NOT NULL,
  `users_firstname` varchar(255) NOT NULL,
  `users_lastname` varchar(255) NOT NULL,
  `users_email` varchar(255) NOT NULL,
  `users_username` varchar(255) NOT NULL,
  `users_password` varchar(255) NOT NULL,
  `users_contact` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `users_firstname`, `users_lastname`, `users_email`, `users_username`, `users_password`, `users_contact`) VALUES
(1, 'Neil', 'Chan', 'Nchan@gmail.com', 'Nchan', 'Nchan', 123123123),
(2, 'Psalter', 'Cea', 'Pcea@gmail.com', 'Pcea', 'Pcea', 321321),
(5, 'Neil Angelo', 'Chan', 'nabchan140@gmail.com', 'AngeloChan', 'AngeloChan', 0),
(8, 'Bench', 'Zapata', 'Bzap@gmail.com', 'Bzap', 'Bzap', 326568),
(10, 'Gelo', 'Hernandez', 'gher@gmail.com', 'Gher', 'gher', 123123213),
(11, 'one', 'one', 'one@gmail.com', 'one ', 'one ', 123123),
(12, 'First', 'Try', 'first@gmail.com', 'first', 'first', 912309123),
(13, 'two', 'two', 'two@mail.com', 'two', 'two', 2),
(14, 'three', 'three', 'three@mail.com', 'three', 'three', 3),
(15, 'po', 'po', 'po', 'po', 'po', 1),
(16, 'pl', 'pl', 'pl', 'pl', 'pl', 2),
(17, 'pm', 'pm', 'pm', 'pm', 'pm', 3),
(18, 'pi', 'pi', 'pi', 'pi', 'pi', 4),
(19, 'pk', 'pk', 'pk', 'pk', 'pk', 5),
(20, 'pu', 'pu', 'pu', 'pu', 'pu', 6),
(21, 'pj', 'pj', 'pj', 'pj', 'pj', 7),
(22, 'pn', 'pn', 'pn', 'pn', 'pn', 8),
(23, 'py', 'py', 'py', 'py', 'py', 9),
(24, 'op', 'op', 'op', 'op', 'op', 10),
(25, 'lp', 'lp', 'lp', 'lp', 'lp', 11),
(26, 'kp', 'kp', 'kp', 'kp', 'kp', 12),
(27, 'jp', 'jp', 'jp', 'jp', 'jp', 13),
(28, 'np', 'np', 'np', 'np', 'np', 14),
(29, 'jh', 'jh', 'jh', 'jh', 'jh', 15),
(30, 'gf', 'tr', 'tr', 'tr', 'tr', 16),
(31, 'dt', 'dt', 'dt', 'dt', 'dt', 17),
(32, 'vy', 'vy', 'vy', 'vy', 'vy', 18),
(33, 'hu', 'gu', 'gu', 'gu', 'gu', 19),
(34, 'uf', 'uf', 'uf', 'uf', 'uf', 20),
(35, 'su', 'su', 'su', 'su', 'su', 21),
(36, 'cu', 'cu', 'cu', 'cu', 'cu', 22),
(37, 'ru', 'ru', 'ru', 'ru', 'ru', 23),
(38, 'tu', 'tu', 'tu', 'tu', 'tu', 24),
(39, 'ok', 'ok', 'ok', 'ok', 'ok', 25),
(40, 'uh', 'uh', 'uh', 'uh', 'uh', 26),
(41, 'ug', 'ug', 'ug', 'ug', 'ug', 27),
(42, 'uy', 'uy', 'uy', 'uy', 'uy', 28),
(43, 'in', 'in', 'in', 'in', 'in', 29),
(44, 'it', 'it', 'it', 'it', 'it', 30),
(45, 'oj', 'oj', 'oj', 'oj', 'oj', 31),
(46, 'ok', 'ok', 'ok', 'ok', 'ok', 32),
(47, 'on', 'on', 'on', 'on', 'on', 33),
(48, 'ui', 'ui', 'ui', 'ui', 'ui', 34),
(49, 'yi', 'yi', 'yi', 'yi', 'yi', 35),
(50, 'ji', 'jij', 'i', 'ji', 'ji', 36),
(51, 'ib', 'ib', 'ib', 'ib', 'ib', 37),
(52, 'oy', 'oy', 'oy', 'oy', 'oy', 38),
(53, 'dp', 'dp', 'dp', 'dp', 'dp', 39),
(54, 'oso', 'oso', 'sos', 'sos', 'oso', 40),
(55, 'asdas', 'asdasd', 'asdasd', 'asdasd', 'qweqwe', 50),
(56, 'Neil', 'Chan', 'first@gmail.com', 'nchan', '121212212', 12121),
(57, 'Neil', 'Chan', 'Nchan@gmail.com', 'Nchan', 'nchan', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`eval_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `evaluation`
--
ALTER TABLE `evaluation`
  MODIFY `eval_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
